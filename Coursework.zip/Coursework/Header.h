#pragma once

extern int key[4][4];
